#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <curses.h>
#include <termios.h> 
#include <fcntl.h>
#include <iostream>

#define ROW 10
#define COLUMN 50 //Actually we only get 49 columns in order to let the frog's initially at the center.
#define MIN_LOG_LEN 10
#define MAX_LOG_LEN 20
#define SCREEN_REFRESH_LAG 10000
#define LOG_MOVE_LAG 100000

pthread_mutex_t frog_mutex;
pthread_mutex_t map_mutex;
pthread_mutex_t log_mutex;

enum DIRECTION {LEFT=-1, RIGHT=1};
enum GAME_STATUS {WIN, LOSE, CONTINUE, QUIT};
GAME_STATUS G_STATUS = CONTINUE;

char map[ROW+10][COLUMN] ; 

struct Node
{
	int x , y; 
	Node( int _x , int _y ) : x( _x ) , y( _y ) {}; 
	Node(){} ; 
} frog ; 

struct Log
{
	int row_id, head, tail;
	DIRECTION dir;
	Log(int _row_id, int _head, int _tail, DIRECTION _dir) :  row_id(_row_id), 
														head(_head), 
														tail(_tail), 
														dir(_dir) {};
	Log() {};

	void refresh_log()
	{	
		pthread_mutex_lock(&map_mutex);
		if (head < tail)
		{
			for (int i = 0; i < COLUMN-1; i++)
			{
				if (i >= head && i <= tail)
				{
					map[row_id][i] = '=';
				}
				else 
				{
					map[row_id][i] = ' ';
				}
			}
		}
		else
		{
			for (int i = 0; i < COLUMN-1; i++)
			{
				if (i > tail && i < head)
				{
					map[row_id][i] = ' ' ;
				}
				else 
				{
					map[row_id][i] = '=';
				}
			}
		}
		pthread_mutex_unlock(&map_mutex);
	}
} Logs[ROW-1];

// Determine a keyboard is hit or not. If yes, return 1. If not, return 0. 
int kbhit(void)
{
	struct termios oldt, newt;
	int ch;
	int oldf;

	tcgetattr(STDIN_FILENO, &oldt);

	newt = oldt;
	newt.c_lflag &= ~(ICANON | ECHO);

	tcsetattr(STDIN_FILENO, TCSANOW, &newt);
	oldf = fcntl(STDIN_FILENO, F_GETFL, 0);

	fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);

	ch = getchar();

	tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
	fcntl(STDIN_FILENO, F_SETFL, oldf);

	if(ch != EOF)
	{
		ungetc(ch, stdin);
		return 1;
	}
	return 0;
}

void print_map()
{
	//Print the map into screen
	pthread_mutex_lock(&map_mutex);
	for(int j = 0; j < COLUMN - 1; ++j )	
		map[ROW][j] = '|' ;

	for(int j = 0; j < COLUMN - 1; ++j )	
		map[0][j] = '|' ;
	
	map[frog.x][frog.y] = '0';

	for(int i = 0; i <= ROW; ++i)	
	{
		puts(map[i]);
	}
	pthread_mutex_unlock(&map_mutex);
}

void init_logs()
{
	srand((unsigned) time(NULL));
	for (int log_id = 0; log_id < ROW-1; log_id++)
	{
		int length = MIN_LOG_LEN + (rand() % (MAX_LOG_LEN-MIN_LOG_LEN));
		int head = 0 + (rand() % 48);
		int tail = head + length - 1;
		tail = (tail + COLUMN-1) % (COLUMN-1);
		if (log_id % 2 == 0)
		{
			Logs[log_id] = Log(log_id+1, head, tail, RIGHT);
		}
		else 
		{
			Logs[log_id] = Log(log_id+1, head, tail, LEFT);
		}
		Logs[log_id].refresh_log();
	}
}

void check_game_status()
{
	int frog_x, frog_y;
	frog_x = frog.x;
	frog_y = frog.y;

	pthread_mutex_lock(&map_mutex);
	if (frog_x == 0) // reach the oppposite river bank
	{
		G_STATUS = WIN;
		pthread_mutex_unlock(&map_mutex);

		return;	
	}

	if (map[frog_x][frog_y] == ' ') // Fall in to river
	{
		G_STATUS = LOSE;
		pthread_mutex_unlock(&map_mutex);
		
		return;
	}

	if (frog_y < 0 || frog_y > COLUMN-2)
	{
		G_STATUS = LOSE;
		pthread_mutex_unlock(&map_mutex);

		return;
	}
	pthread_mutex_unlock(&map_mutex);
}

void move_frog(int x, int y)
{
	pthread_mutex_lock(&frog_mutex);
	frog.x += x;
	frog.y += y;
	pthread_mutex_unlock(&frog_mutex);
}

void *logs_thread( void *t )
{
	int log_id = *(int*)t;
	DIRECTION dir = Logs[log_id].dir;

	while(G_STATUS == CONTINUE)
	{
		usleep(LOG_MOVE_LAG);
		if (dir == LEFT)
		{
			Logs[log_id].head = ((Logs[log_id].head - 1) + COLUMN-1) % (COLUMN-1);
			Logs[log_id].tail = ((Logs[log_id].tail - 1) + COLUMN-1) % (COLUMN-1);
		}
		else 
		{
			Logs[log_id].head = ((Logs[log_id].head + 1)) % (COLUMN-1);
			Logs[log_id].tail = ((Logs[log_id].tail + 1)) % (COLUMN-1);
		}
		if (frog.x == log_id+1)
		{
			if (dir == LEFT) move_frog(0, -1);
			else move_frog(0, 1);
		}
 	}
	pthread_exit(NULL);
}

void *frog_thread(void *t) 
{
	while(G_STATUS == CONTINUE)
	{
		if (kbhit())
		{
			char move = getchar();
			switch(move)
			{
				case 'W':
				case 'w':
				{
					move_frog(-1, 0);
					break;
				}
				case 'A':
				case 'a' :
				{
					move_frog(0, -1);
					break;
				}
				case 'S':
				case 's':
				{
					if (frog.x == ROW) continue;
					move_frog(1, 0);
					break;
				}
				case 'D':
				case 'd' :
				{
					move_frog(0, 1);
					break;
				}
				case 'Q':
				case 'q':
				{
					G_STATUS = QUIT;
					puts("\033[H\033[2J");
					pthread_exit(NULL);
				}
			}
		}
		for (int log_id = 0; log_id < ROW-1; log_id++)
		{
			Logs[log_id].refresh_log();
		}
		check_game_status();
		if (G_STATUS == LOSE) pthread_exit(NULL);
		puts("\033[H\033[2J");
		print_map();
		usleep(SCREEN_REFRESH_LAG);
	}
	pthread_exit(NULL);
}

int main( int argc, char *argv[] )
{

	// Initialize the river map and frog's starting position
	memset( map , 0, sizeof( map ) ) ;
	int i , j ; 
	for( i = 1; i < ROW; ++i ){	
		for( j = 0; j < COLUMN - 1; ++j )	
			map[i][j] = ' ' ;  
	}	

	for( j = 0; j < COLUMN - 1; ++j )	
		map[ROW][j] = '|' ;

	for( j = 0; j < COLUMN - 1; ++j )	
		map[0][j] = '|' ;

	frog = Node( ROW, (COLUMN-1) / 2 ) ; 
	map[frog.x][frog.y] = '0' ; 

	init_logs();

	/*  Create pthreads for wood move and frog control.  */
	pthread_t pthread_logs[ROW-1];
    pthread_t pthread_frog;
	pthread_t pthread_print;

	pthread_mutex_init(&frog_mutex, NULL);
	pthread_mutex_init(&log_mutex, NULL);
	pthread_mutex_init(&map_mutex, NULL);

	int logs_id[ROW-1];
	void *unused;
	for (int i = 0; i < ROW-1; i++)
	{
		logs_id[i] = i;
	}
	pthread_create(&pthread_frog, NULL, frog_thread, unused);
	for (int i = 0; i < ROW-1; i++)
	{
		pthread_create(&pthread_logs[i], NULL, logs_thread, (void*)&logs_id[i]);
	}

	pthread_join(pthread_frog, NULL);

	for (int i = 0; i < ROW-1; i++)
	{
		pthread_join(pthread_logs[i], NULL);	
	}
	/*  Display the output for user: win, lose or quit.  */
	std::system("clear");	
	if (G_STATUS == WIN)
	{
		std::cout << "You win the GAME\n";
	}
	else if (G_STATUS == LOSE)
	{
		std::cout << "You lose the GAME\n";
	}
	else if (G_STATUS == QUIT)
	{
		std::cout << "You quit the GMAE\n";
	}


	return 0;

}
