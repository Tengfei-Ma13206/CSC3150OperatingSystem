This is the readme of Assignment_2

CONTENTS:
	hw2.cpp
	README
	
	HOW TO COMPILE:
		In the 'source' directory, type 'g++ hw2.cpp -lpthread' and enter on concole.
		
		
	HOW TO EXECUTE:
		In the 'source' directory, type './a.out',
